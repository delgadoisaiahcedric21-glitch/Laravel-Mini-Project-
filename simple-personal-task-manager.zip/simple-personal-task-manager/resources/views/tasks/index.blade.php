<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Task Manager</title>
    <style>
        * { box-sizing: border-box; }
        body { margin:0; font-family:Arial,sans-serif; background:#f5f5f5; color:#222; }
        .container { max-width:1000px; margin:40px auto; padding:20px; }
        .top { display:flex; justify-content:space-between; align-items:center; gap:15px; flex-wrap:wrap; }
        h1 { margin-bottom:5px; }
        .subtitle { color:#666; }
        .button { background:#222; color:white; padding:11px 16px; border-radius:7px; text-decoration:none; display:inline-block; }
        .message { background:#e8f7e8; color:#216b21; padding:12px; border-radius:7px; margin:20px 0; }
        .table-box { background:white; border-radius:10px; overflow:auto; margin-top:20px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
        table { width:100%; border-collapse:collapse; min-width:750px; }
        th,td { padding:14px; border-bottom:1px solid #eee; text-align:left; }
        th { background:#fafafa; }
        .badge { padding:5px 9px; border-radius:20px; font-size:13px; }
        .pending { background:#fff1c7; }
        .completed { background:#dff5e1; }
        .edit { color:#1d5fbf; text-decoration:none; margin-right:8px; }
        .delete { border:0; background:#d9363e; color:white; padding:7px 10px; border-radius:5px; cursor:pointer; }
        .empty { text-align:center; color:#777; padding:35px; }
        @media(max-width:600px){ .container{margin:20px auto;} }
    </style>
</head>
<body>
<div class="container">
    <div class="top">
        <div>
            <h1>My Task Manager</h1>
            <div class="subtitle">A simple way to keep track of my tasks.</div>
        </div>
        <a href="{{ route('tasks.create') }}" class="button">+ Add Task</a>
    </div>

    @if(session('success'))
        <div class="message">{{ session('success') }}</div>
    @endif

    <div class="table-box">
        @if($tasks->count())
        <table>
            <tr>
                <th>Task</th>
                <th>Description</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Action</th>
            </tr>
            @foreach($tasks as $task)
            <tr>
                <td><strong>{{ $task->task_name }}</strong></td>
                <td>{{ $task->description }}</td>
                <td><span class="badge {{ strtolower($task->status) }}">{{ $task->status }}</span></td>
                <td>{{ $task->due_date }}</td>
                <td>
                    <a class="edit" href="{{ route('tasks.edit', $task) }}">Edit</a>
                    <form action="{{ route('tasks.destroy', $task) }}" method="POST" style="display:inline" onsubmit="return confirm('Delete this task?')">
                        @csrf
                        @method('DELETE')
                        <button class="delete">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </table>
        @else
            <div class="empty">No tasks yet. Click <b>+ Add Task</b> to create your first task.</div>
        @endif
    </div>
</div>
</body>
</html>
