<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Task</title>
    <style>
        body{font-family:Arial;background:#f5f5f5;margin:0;padding:30px}.box{max-width:600px;margin:auto;background:white;padding:25px;border-radius:10px}label{display:block;margin-top:15px;margin-bottom:6px;font-weight:bold}input,textarea,select{width:100%;padding:11px;border:1px solid #ccc;border-radius:6px}textarea{height:120px;resize:vertical}.buttons{margin-top:20px}.save{background:#222;color:white;border:0;padding:11px 18px;border-radius:6px;cursor:pointer}.cancel{margin-left:10px;color:#555;text-decoration:none}.errors{background:#ffe5e5;color:#a40000;padding:12px;border-radius:6px}
    </style>
</head>
<body>
<div class="box">
    <h1>Add New Task</h1>
    @if($errors->any())
        <div class="errors"><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif
    <form action="{{ route('tasks.store') }}" method="POST">
        @csrf
        <label>Task Name</label>
        <input type="text" name="task_name" value="{{ old('task_name') }}" placeholder="Example: Finish assignment">
        <label>Description</label>
        <textarea name="description" placeholder="Write a short description...">{{ old('description') }}</textarea>
        <label>Status</label>
        <select name="status"><option value="Pending">Pending</option><option value="Completed">Completed</option></select>
        <label>Due Date</label>
        <input type="date" name="due_date" value="{{ old('due_date') }}">
        <div class="buttons"><button class="save" type="submit">Save Task</button><a class="cancel" href="{{ route('tasks.index') }}">Cancel</a></div>
    </form>
</div>
</body>
</html>
