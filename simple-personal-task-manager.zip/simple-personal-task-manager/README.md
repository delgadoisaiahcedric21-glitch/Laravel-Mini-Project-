# Personal Task Manager

A simple Laravel CRUD project for managing personal or school tasks.

## Project Information

- **Project Code:** WST21-PM-2026-SF
- **Student Name:** Isaiah Cedric Delgado
- **Course & Year:** [Your Course & Year]
- **Database:** MySQL

## Features

- Add Task
- View Tasks
- Edit Task
- Delete Task
- Update Status (Pending / Completed)

## Technologies

- Laravel
- PHP
- MySQL
- Blade
- XAMPP

## How to Run

1. Start Apache and MySQL in XAMPP.
2. Create a database named `personal_task_manager` in phpMyAdmin.
3. Create a Laravel project:

```bash
composer create-project laravel/laravel personal-task-manager
```

4. Copy the files from this package into the Laravel project.
5. In `.env`, use:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=personal_task_manager
DB_USERNAME=root
DB_PASSWORD=
```

6. Run:

```bash
php artisan key:generate
php artisan migrate
php artisan serve
```

7. Open `http://127.0.0.1:8000/tasks`.

## Simple CRUD Flow

Route → Controller → Model → MySQL Database → Blade View
