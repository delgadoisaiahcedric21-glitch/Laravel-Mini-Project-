# Personal Task Manager

**Project Code:** WST21-PM-2026-SF  
**Student Name:** Isaiah Cedric Delgado  
**Course & Year:** [Your Course & Year]  
**Database Used:** MySQL

## Features
- Add Task
- View Tasks
- Edit Task
- Delete Task
- Update Status (Pending / Completed)
- Form validation
- Responsive dashboard-style interface
- Task statistics

## Technologies Used
- Laravel
- PHP
- MySQL
- Blade
- HTML/CSS
- XAMPP

## Setup

### 1. Create the Laravel project
If you do not already have a Laravel project:
```cmd
cd C:\xampp\htdocs
composer create-project laravel/laravel personal-task-manager
```
Then copy the files in this package into that Laravel project, replacing the matching files.

### 2. Configure MySQL
Start Apache and MySQL in XAMPP. Open phpMyAdmin and create:
`personal_task_manager`

In `.env`:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=personal_task_manager
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Run Laravel
```cmd
php artisan key:generate
php artisan migrate
php artisan serve
```
Open `http://127.0.0.1:8000/tasks`.

## GitHub
```cmd
git init
git add .
git commit -m "Initial Personal Task Manager"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Make the GitHub repository **Public**. Never upload `.env`.
