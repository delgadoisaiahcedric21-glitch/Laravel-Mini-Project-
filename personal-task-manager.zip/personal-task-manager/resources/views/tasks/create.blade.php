@extends('layouts.app')
@section('title','Add Task')
@section('content')<div class="form-card"><div class="hero"><div><h1>Add Task</h1><p class="subtitle">Create a new task and set its deadline.</p></div></div><div class="card">@if($errors->any())<div class="errors"><strong>Please fix the following:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<form action="{{ route('tasks.store') }}" method="POST">@csrf
<div class="field"><label for="task_name">Task Name</label><input id="task_name" name="task_name" type="text" value="{{ old('task_name') }}" required maxlength="255" placeholder="e.g. Finish Laravel project"></div>
<div class="field"><label for="description">Description</label><textarea id="description" name="description" placeholder="Add task details...">{{ old('description') }}</textarea></div>
<div class="field"><label for="status">Status</label><select id="status" name="status" required><option value="Pending" @selected(old('status','Pending')==='Pending')>Pending</option><option value="Completed" @selected(old('status')==='Completed')>Completed</option></select></div>
<div class="field"><label for="due_date">Due Date</label><input id="due_date" name="due_date" type="date" value="{{ old('due_date') }}"></div><div class="actions"><button class="btn btn-primary" type="submit">Save Task</button><a class="btn btn-secondary" href="{{ route('tasks.index') }}">Cancel</a></div></form></div></div>@endsection
