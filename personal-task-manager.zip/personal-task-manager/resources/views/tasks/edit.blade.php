@extends('layouts.app')
@section('title','Edit Task')
@section('content')<div class="form-card"><div class="hero"><div><h1>Edit Task</h1><p class="subtitle">Update your task information.</p></div></div><div class="card">@if($errors->any())<div class="errors"><strong>Please fix the following:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<form action="{{ route('tasks.update',$task) }}" method="POST">@csrf @method('PUT')
<div class="field"><label for="task_name">Task Name</label><input id="task_name" name="task_name" type="text" value="{{ old('task_name',$task->task_name) }}" required maxlength="255"></div>
<div class="field"><label for="description">Description</label><textarea id="description" name="description">{{ old('description',$task->description) }}</textarea></div>
<div class="field"><label for="status">Status</label><select id="status" name="status" required><option value="Pending" @selected(old('status',$task->status)==='Pending')>Pending</option><option value="Completed" @selected(old('status',$task->status)==='Completed')>Completed</option></select></div>
<div class="field"><label for="due_date">Due Date</label><input id="due_date" name="due_date" type="date" value="{{ old('due_date',optional($task->due_date)->format('Y-m-d')) }}"></div><div class="actions"><button class="btn btn-primary" type="submit">Update Task</button><a class="btn btn-secondary" href="{{ route('tasks.index') }}">Cancel</a></div></form></div></div>@endsection
